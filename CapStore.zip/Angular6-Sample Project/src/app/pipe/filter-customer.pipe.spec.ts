import { FilterCustomerPipe } from './filter-customer.pipe';

describe('FilterCustomerPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCustomerPipe();
    expect(pipe).toBeTruthy();
  });
});
