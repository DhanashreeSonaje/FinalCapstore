export class Coupon{
    
    couponId:number;
    couponCode:String;
    userId:number;
    couponEndDate:Date;
    couponStartDate:Date;
    couponAmount:number;
    couponMinOrderAmount:number;
    issuedBy:String;
}