export class ProductFeedback{

    feedbackId:number;
    feedbackSubject:String;
    feedbackMessage:String;
    productId:number;
  //  us_id:String;
}