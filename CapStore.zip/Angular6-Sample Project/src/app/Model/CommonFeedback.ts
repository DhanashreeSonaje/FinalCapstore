export class CommonFeedback{

    feedbackId:number;
    feedbackSubject:String;
    feedbackMessage:String;
    userId:number;
    productId:number;
    requestFlag:boolean;
    responseFlag:boolean;
    requestApproved:boolean;
    responseApproved:boolean;
    responseMessage:String;

}